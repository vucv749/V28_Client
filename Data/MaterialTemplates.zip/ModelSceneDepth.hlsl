
#ifndef MAX_BLEND_WEIGHTS
	#define MAX_BLEND_WEIGHTS	0
#endif

#if MAX_BLEND_WEIGHTS > 0
	#ifndef MAX_WORLD_MATRICES
	    #define MAX_WORLD_MATRICES	75
	#endif
	
	#ifndef USE_LAST_WEIGHT
	    #if MAX_BLEND_WEIGHTS != 3
	        #define USE_LAST_WEIGHT     1
	    #else
	        #define USE_LAST_WEIGHT     0
	    #endif
	#endif
#endif

void DrawDepth_VS(
            in float4 position : POSITION,
            in float4 texcoord : TEXCOORD0,
            #if MAX_BLEND_WEIGHTS > 0
            	in int4 blendIndex : BLENDINDICES,
              in float4 blendWeight : BLENDWEIGHT,
            	uniform float3x4 worldMatrix3x4Array[MAX_WORLD_MATRICES],
            #else
            	uniform float4x4 world_matrix,
            #endif
						uniform float4x4 viewproj_matrix,
						uniform float4x4 view_matrix,
						
            out float4 oPosition : POSITION,
            out float4 oTcDepth : TEXCOORD0)
{
		// transform to world space by indexed matrices
		float3 blendPos = float3(0,0,0);
#if MAX_BLEND_WEIGHTS > 0
		
	#if USE_LAST_WEIGHT
	    // Use this to avoid weight by last component of blendWeights, which
	    // maybe wrong when number of weights equal four.
	    float lastWeight = 1;
	
	    #if MAX_BLEND_WEIGHTS > 1
	        for (int i = 0; i < MAX_BLEND_WEIGHTS-1; ++i)
	        {
	            lastWeight -= blendWeight[i];
	            blendPos += mul(worldMatrix3x4Array[blendIndex[i]], position) * blendWeight[i];
	        }
	    #endif
			lastWeight = step(0.001, lastWeight) * lastWeight;
	    blendPos += mul(worldMatrix3x4Array[blendIndex[MAX_BLEND_WEIGHTS-1]], position) * lastWeight;
	
	
	#else // !USE_LAST_WEIGHT
	
	    for (int i = 0; i < MAX_BLEND_WEIGHTS; ++i)
	    {
	        blendPos += mul(worldMatrix3x4Array[blendIndex[i]], position)
	        #if MAX_BLEND_WEIGHTS > 1
	            * blendWeight[i]
	        #endif
	            ;
	    }
	#endif // USE_LAST_WEIGHT
		
#else
		blendPos = mul(world_matrix, float4(position.xyz, 1.0)).xyz;
#endif
		oPosition = mul( viewproj_matrix, float4(blendPos, 1.0) );
		
		float4 posInView = mul( view_matrix, float4(blendPos, 1.0) );
		oTcDepth = float4(texcoord.xy, -posInView.z, 0);
}

/////////////////////////////////////// fp_main //////////////////////////////////
void DrawDepth_PS(
      in float4 tcDepth       : TEXCOORD0,
    #if ALPHATEST_ENABLE
      uniform sampler2D baseTex : register(s0),
      uniform float alphaRef,
    #endif
		out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,1.0,1.0);  
    
    #if ALPHATEST_ENABLE
			float4 baseTexColour = tex2D(baseTex, tcDepth.xy);
			clip( baseTexColour.a - alphaRef );
		#endif

		oColour.x = tcDepth.z;
}



