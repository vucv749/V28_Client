/////////////////////////////////////// vp_main //////////////////////////////////
#ifndef MAX_WORLD_MATRICES
    #define MAX_WORLD_MATRICES	25
#endif

#ifndef MAX_BLEND_WEIGHTS
    #define MAX_BLEND_WEIGHTS	1
#endif

#ifndef USE_LAST_WEIGHT
    #if MAX_BLEND_WEIGHTS != 3
        #define USE_LAST_WEIGHT     1
    #else
        #define USE_LAST_WEIGHT     0
    #endif
#endif

#ifndef NUM_TEXCOORDS
    #define NUM_TEXCOORDS       1
#endif

#if NUM_TEXCOORDS > 0

    #define ORIGINAL_TEXCOORD   0
    #define SINGLE_TEXCOORD     1
    #define PROJECTION_TEXCOORD 2

    #ifndef TEXCOORD_SOURCE
        #define TEXCOORD_SOURCE     ORIGINAL_TEXCOORD
    #endif

#endif

#ifndef LIGHTING_AMBIENT
    #define LIGHTING_AMBIENT    0
#endif

#ifndef USE_TANGENT
    #define USE_TANGENT          0
#endif

#ifndef USE_VERTEXCOLOR
    #define USE_VERTEXCOLOR          0
#endif

#ifndef LIGHT_ENABLE
    #define LIGHT_ENABLE          1
   	#ifndef NUM_LIGHTS
    	#define NUM_LIGHTS          3
		#endif
#endif

#ifndef TEX_EFFECT_0
	#define TEX_EFFECT_0 0
#endif

#ifndef TEX_EFFECT_1
	#define TEX_EFFECT_1 0
#endif

#ifndef ENABLE_DIFFUSE_2
	#define ENABLE_DIFFUSE_2 0
#endif

#define BLEND_OP_MODULATE   0
#define BLEND_OP_MODULATE2     1
#define BLEND_OP_MODULATE4     2
#define BLEND_OP_ADD     3
#define BLEND_OP_CUSTOM     4

// process the ColorOp of texUnit0
#if NUM_TEXCOORDS > 0
	#ifndef BLEND_OP_0
			#define BLEND_OP_0 BLEND_OP_MODULATE
	#endif
#endif

// process the ColorOp of texUnit1
#if ENABLE_DIFFUSE_2 > 0
	#ifndef BLEND_OP_1
			#define BLEND_OP_1 BLEND_OP_MODULATE
	#endif
#endif

#define PI 3.14159265359
 #define ColorSpaceDielectricSpec float4(0.220916301, 0.220916301, 0.220916301, 1.0 - 0.220916301)
 
 
 
 
void vp_main(
            in float4 position : POSITION,
            in int4 blendIndex : BLENDINDICES,
            #if MAX_BLEND_WEIGHTS > 1
                in float4 blendWeight : BLENDWEIGHT,
            #endif
            in float3 normal : NORMAL,
            #if USE_TANGENT
		            in float4 tangent : TANGENT,
		        #endif
		        #if USE_VERTEXCOLOR
		            in float4 vColor : COLOR0,
		        #endif

            out float4 oPosition : POSITION,
						out float3 oNormal : TEXCOORD2,
		        out float3 oViewDir : TEXCOORD3, 
		        out float3 oTangent : TEXCOORD4,
		        out float3 oPos : TEXCOORD5,
		        out float3 oBiTangent : TEXCOORD6,
            
            out float4 oColour : COLOR0,
            
            #if NUM_TEXCOORDS > 0
               			#if TEX_EFFECT_0
                        uniform float4x4 textureTransMatrix0,
                    #endif
                    #if TEX_EFFECT_1
                    		uniform float4x4 textureTransMatrix1,
                    #endif
                				in float4 uv0 : TEXCOORD0,
                		#if USE_TANGENT
                				in float4 uv1 : TANGENT,
                		#endif
                        out float4 oTexcoords : TEXCOORD0,
                        out float4 oUVExtern : TEXCOORD1,
            #endif
            
						uniform float4 cameraPos,
            uniform float4x4 viewproj_matrix,
            uniform float3x4 worldMatrix3x4Array[MAX_WORLD_MATRICES] )
{

    #if USE_TANGENT
        tangent =  uv1;
    #endif
    // transform to world space by indexed matrices
    float3 blendPos = float3(0,0,0);
    float3 blendNorm = float3(0,0,0);
    float3 blendTanget = float3(0,0,0);
    float3 blendBiTangent = float3(0,0,0);

#if USE_LAST_WEIGHT
    // Use this to avoid weight by last component of blendWeights, which
    // maybe wrong when number of weights equal four.
    float lastWeight = 1;

    #if MAX_BLEND_WEIGHTS > 1
        for (int i = 0; i < MAX_BLEND_WEIGHTS-1; ++i)
        {
            lastWeight -= blendWeight[i];
            blendPos += mul(worldMatrix3x4Array[blendIndex[i]], position) * blendWeight[i];
            
            blendNorm += mul( (float3x3)worldMatrix3x4Array[blendIndex[i]], normal ) * blendWeight[i];
            #if USE_TANGENT
            blendTanget += mul( (float3x3)worldMatrix3x4Array[blendIndex[i]], tangent ) * blendWeight[i];
            #endif
        }
    #endif
		lastWeight = step(0.001, lastWeight) * lastWeight;
    blendPos += mul(worldMatrix3x4Array[blendIndex[MAX_BLEND_WEIGHTS-1]], position) * lastWeight;
    blendNorm += mul( (float3x3)worldMatrix3x4Array[blendIndex[MAX_BLEND_WEIGHTS-1]], normal ) * lastWeight;
    #if USE_TANGENT
    blendTanget += mul( (float3x3)worldMatrix3x4Array[blendIndex[MAX_BLEND_WEIGHTS-1]], tangent ) * lastWeight;
    #endif

#else // !USE_LAST_WEIGHT

    for (int i = 0; i < MAX_BLEND_WEIGHTS; ++i)
    {
        blendPos += mul(worldMatrix3x4Array[blendIndex[i]], position)
        #if MAX_BLEND_WEIGHTS > 1
            * blendWeight[i]
        #endif
            ;
				blendNorm += mul((float3x3)worldMatrix3x4Array[blendIndex[i]], normal)
        #if MAX_BLEND_WEIGHTS > 1
            * blendWeight[i]
        #endif
            ;
        #if USE_TANGENT
        blendTanget += mul((float3x3)worldMatrix3x4Array[blendIndex[i]], tangent)
        #if MAX_BLEND_WEIGHTS > 1
            * blendWeight[i]
        #endif
            ;
        #endif
    }
#endif // USE_LAST_WEIGHT
oPos = blendPos;
    // view / projection
    oPosition = mul( viewproj_matrix, float4(blendPos, 1.0) );
    blendNorm = normalize(blendNorm);
    blendTanget = normalize(float4(blendTanget, 1.0)).xyz;

		oNormal.r = - blendNorm.r;
		oNormal.gb =  blendNorm.gb;
		
	  #if USE_TANGENT
			oTangent.r = -blendTanget.r;
			oTangent.gb = blendTanget.gb;	
			oBiTangent = -normalize(cross(oNormal, oTangent)) * tangent.w;   
			oTangent.r = -blendTanget.r;   
		#endif
		    
		    		oNormal.r = - blendNorm.r;

		//oTangent = blendTanget;
		oViewDir = cameraPos.xyz - blendPos.xyz;
		
#if NUM_TEXCOORDS > 0
    // Calculate texcoords
    #if TEX_EFFECT_0
    	oTexcoords = mul( textureTransMatrix0, uv0 );
    #else
    	oTexcoords = uv0;
    #endif
    #if TEX_EFFECT_1
    	oUVExtern = mul( textureTransMatrix1, uv0 );
    #else
    	oUVExtern = uv0;
		#endif
#endif
    
    oColour = float4(1.0,1.0,1.0,1.0);
    #if USE_VERTEXCOLOR
    	oColour *= vColor;
    #endif
}

/////////////////////////////////////// fp_main //////////////////////////////////

float blinn( float3 n, float3 v, float3 l, float exp )
{
		float fNormFactor = exp * 0.159155h + 0.31831h;
		float3 h = normalize(v + l);
		return fNormFactor * pow( saturate(dot(n,h)), exp );
		return pow( saturate(dot(n,h)), exp );
}

float anitrophic( float3 n, float3 v, float3 l, float3 t, float exp )
{
		float3 h = normalize(v + l);
    float dotTH = dot(t, h);
    float sinTH = sqrt(1.0 - dotTH * dotTH);
    float dirAttr = smoothstep(-1, 0, dotTH);
		return dirAttr * pow(sinTH, exp *3);
}

float3 Fogging(float3 finalColour, float depthInView, float4 fogType, float4 fogParam, float4 fogColor)
{
		float fogFactor = 0.0;
		fogFactor += fogType[0];
		fogFactor += fogType[1] * exp(- depthInView * fogParam.x);
		fogFactor += fogType[2] * exp(- (depthInView * fogParam.x) * (depthInView * fogParam.x));
		fogFactor += fogType[3] * saturate((fogParam.z - depthInView) * fogParam.w);
		float3 color = finalColour.rgb * fogFactor + fogColor.rgb * (1 - fogFactor);
		return color;
}


void fp_main(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D baseTex : register(s0),
      #if ENABLE_DIFFUSE_2
      		uniform sampler2D diffuse2Tex : register(s1),
      	#if BLEND_OP_1 == BLEND_OP_CUSTOM
      		uniform sampler2D blend2Tex 	: register(s2),
      	#endif
      #endif
    #endif
    
    	  in float3 normal : TEXCOORD2,
	      in float3 viewDir	: TEXCOORD3,
	      in float3 tangent : TEXCOORD4,
	      in float3 pos : TEXCOORD5,
		    
		    in float4 colour		: COLOR0,
		    
    #if LIGHT_ENABLE
    		uniform float4 derived_scene_colour,
    		uniform float4 surface_diffuse_colour,
    		uniform float4 surface_specular_colour,
        uniform float  surface_shininess,
        uniform float4 lightSpecular0,
        uniform float4 light_position_array[NUM_LIGHTS],
		    uniform float4 light_attenuation_array[NUM_LIGHTS],         
		    uniform float4 derived_light_diffuse_colour_array[NUM_LIGHTS],
		    
		    uniform float4 actor_ambient_params,
		    uniform float4 actor_lightone_params,
		    uniform float4 actor_lighttwo_params,
		    uniform float4 userflag,
    #endif
    
    #if ENABLE_SPHEREMAPPING_TEX
				uniform sampler2D sphereMappingTex : register(s1),
    #endif
    		uniform float4 fog_type,
    		uniform float4 fog_params,
    		uniform float4 fog_colour,
    		uniform float4x4 view_matrix,
    		//uniform float4 tex0BlendColor,
    		uniform float4 multiBlendColor,
	
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);
    
		#if NUM_TEXCOORDS > 0
			
			float4 stageColor = float4(1.0,1.0,1.0,1.0);
			float4 baseTexColour = tex2D(baseTex, uv.xy);

      #if BLEND_OP_0 == 1
      	stageColor.xyz *= baseTexColour.xyz * 2.0;
    	#elif BLEND_OP_0 == 2
      	stageColor.xyz *= baseTexColour.xyz * 4.0;
    	#elif BLEND_OP_0 == 3
      	stageColor.xyz += baseTexColour.xyz;
    	#else
    		stageColor.xyz *= baseTexColour.xyz;
    	#endif
    	stageColor.w *= baseTexColour.w;
      
      #if ENABLE_DIFFUSE_2
				float4 diffuse2TexColour = tex2D(diffuse2Tex, uvExtern.xy);
      	#if BLEND_OP_1 == 1
      		stageColor.xyz *= diffuse2TexColour.xyz * 2.0;
      	#elif BLEND_OP_1 == 2
      		stageColor.xyz *= diffuse2TexColour.xyz * 4.0;
      	#elif BLEND_OP_1 == 3
      		stageColor.xyz += diffuse2TexColour.xyz;
      	#elif BLEND_OP_1 == 4
      		float factor = tex2D( blend2Tex, uv.xy ).r;
      		stageColor.xyz = lerp( stageColor.xyz, diffuse2TexColour.xyz, factor );
      	#else
      		stageColor.xyz *= diffuse2TexColour.xyz;
      	#endif
      	stageColor.w *= diffuse2TexColour.w;
			#endif

			oColour = stageColor;
    #endif
    
    oColour *= colour;
    
    #if LIGHT_ENABLE
    float3 Nn = normalize(normal);
		float3 Vn = normalize(viewDir);
		float3 Tn = normalize(float4(tangent, 1.0)).xyz;
    
    float4 sceneColor = derived_scene_colour * (1.0 - userflag.x) + actor_ambient_params * userflag.x;
    
    float4 lightDiffuseColor[NUM_LIGHTS];
		lightDiffuseColor[0] = derived_light_diffuse_colour_array[0] * (1.0 - userflag.x) + actor_lightone_params * surface_diffuse_colour * userflag.x;
		lightDiffuseColor[1] = derived_light_diffuse_colour_array[1] * (1.0 - userflag.x) + actor_lighttwo_params * surface_diffuse_colour * userflag.x;
		lightDiffuseColor[2] = derived_light_diffuse_colour_array[2];
    
    float3 LightDiffuse = float3(0.0,0.0,0.0);
    float3 LightSpecular = float3(0.0,0.0,0.0);
    for (int l = 0; l < NUM_LIGHTS; ++l)
    {
    		float3 lightDir = light_position_array[l].xyz - (pos * light_position_array[l].w);
    		float d = length(lightDir);
    		float3 Ln = lightDir / d;
    		float fNdotL = dot(Nn, Ln);

        float att = lerp(0, 1, 1 / dot(float3(1, d, d*d), light_attenuation_array[l].yzw));
        LightDiffuse += att * max(fNdotL, 0) * lightDiffuseColor[l].rgb;
        if (l == 0)
        {
				LightSpecular += blinn(Nn, Vn, Ln, surface_shininess) * lightSpecular0.xyz * surface_specular_colour.xyz;
				}
     }
    
    oColour.rgb = oColour.rgb * saturate(LightDiffuse + sceneColor.rgb) + LightSpecular;
    oColour.a *= sceneColor.a;
		#endif
		
    #if ENABLE_SPHEREMAPPING_TEX
  		float4 sphereTexColor = float4(0.0, 0.0, 0.0, 1.0);
  		float2 sphereTexUV = normalize(mul(view_matrix, float4(normal, 0.0))).xy*0.5 + 0.5;
  		sphereTexColor = tex2D(sphereMappingTex, sphereTexUV);
  		oColour.xyz = (oColour.xyz + sphereTexColor.xyz) - oColour.xyz * sphereTexColor.xyz;
		#endif
		
		// cal fog
	  float4 posInView = mul(view_matrix, float4(pos.xyz, 1.0));
	  oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
		
		oColour.xyz *= multiBlendColor.xyz * multiBlendColor.w;
}

/////////////////////////////////////// fp_Cloth_Silk //////////////////////////////////


void fp_main_silk(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D baseTex : register(s0),
      	uniform sampler2D blend2Tex 	: register(s1),
    #endif
    
    	  in float3 normal : TEXCOORD2,
	      in float3 viewDir	: TEXCOORD3,
	      in float3 tangent : TEXCOORD4,
		    in float3 pos : TEXCOORD5,
		    
		    in float4 colour		: COLOR0,
		    
    #if LIGHT_ENABLE
    		uniform float4 derived_scene_colour,
    		uniform float4 surface_diffuse_colour,
    		uniform float4 surface_specular_colour,
        uniform float  surface_shininess,
        uniform float4 lightSpecular0,
        uniform float4 light_position_array[NUM_LIGHTS],
		    uniform float4 light_attenuation_array[NUM_LIGHTS],         
		    uniform float4 derived_light_diffuse_colour_array[NUM_LIGHTS],
		    
		    uniform float4 actor_ambient_params,
		    uniform float4 actor_lightone_params,
		    uniform float4 actor_lighttwo_params,
		    uniform float4 userflag,
    #endif
    
    #if ENABLE_SPHEREMAPPING_TEX
				uniform sampler2D sphereMappingTex : register(s1),
    #endif
    		
    		uniform float4 fog_type,
    		uniform float4 fog_params,
    		uniform float4 fog_colour,
    		uniform float4x4 view_matrix,
    		//uniform float4 tex0BlendColor,
    		uniform float4 multiBlendColor,
	
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);
    float specularRadio = 0.0;
    float specularShift = 0.0;
		#if NUM_TEXCOORDS > 0
			
			oColour = tex2D(baseTex, uv.xy);
			float4 specularTexColor = tex2D(blend2Tex, uv.xy);
			specularRadio = specularTexColor.r;
    #endif
    
    oColour *= colour;
    
    #if LIGHT_ENABLE
    float3 Nn = normalize(normal);
		float3 Vn = normalize(viewDir);
		
		// calculate bn
		float3 Tn = -normalize(cross(Nn, tangent));
		Tn = normalize(float4(Tn + Nn * specularShift, 1.0)).xyz;
    
    float4 sceneColor = derived_scene_colour * (1.0 - userflag.x) + actor_ambient_params * userflag.x;
    
    float4 lightDiffuseColor[NUM_LIGHTS];
		lightDiffuseColor[0] = derived_light_diffuse_colour_array[0] * (1.0 - userflag.x) + actor_lightone_params * surface_diffuse_colour * userflag.x;
		lightDiffuseColor[1] = derived_light_diffuse_colour_array[1] * (1.0 - userflag.x) + actor_lighttwo_params * surface_diffuse_colour * userflag.x;
		lightDiffuseColor[2] = derived_light_diffuse_colour_array[2];
    
    float3 LightDiffuse = float3(0.0,0.0,0.0);
    float3 LightSpecular = float3(0.0,0.0,0.0);
    for (int l = 0; l < NUM_LIGHTS; ++l)
    {
    		float3 lightDir = light_position_array[l].xyz - (pos * light_position_array[l].w);
    		float d = length(lightDir);
    		float3 Ln = lightDir / d;
    		float fNdotL = dot(Nn, Ln);

        float att = lerp(0, 1, 1 / dot(float3(1, d, d*d), light_attenuation_array[l].yzw));
        LightDiffuse += att * max(fNdotL, 0) * lightDiffuseColor[l].rgb;
        
        if (l == 0)
        {
				LightSpecular += anitrophic(Nn, Vn, Ln, Tn, surface_shininess) * lightSpecular0.xyz * surface_specular_colour.xyz;
				}
     }

    oColour.rgb = oColour.rgb * saturate(LightDiffuse + sceneColor.rgb) + specularRadio*LightSpecular*20;
		oColour.a *= sceneColor.a;
		#endif
    
    #if ENABLE_SPHEREMAPPING_TEX
  		float4 sphereTexColor = float4(0.0, 0.0, 0.0, 1.0);
  		float2 sphereTexUV = normalize(mul(view_matrix, float4(normal, 0.0))).xy*0.5 + 0.5;
  		sphereTexColor = tex2D(sphereMappingTex, sphereTexUV);
  		oColour.xyz = (oColour.xyz + sphereTexColor.xyz) - oColour.xyz * sphereTexColor.xyz;
		#endif
		// cal fog
	  float4 posInView = mul(view_matrix, float4(pos.xyz, 1.0));
	  oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
		
		oColour.rgb *= multiBlendColor.xyz * multiBlendColor.w;
}

			float3 Pow5 (float3 x)
{
    return x*x * x*x * x;
}

			//////F
			float3 FresnelTerm (float3 F0, float cosA)
			 {
			     float t = Pow5 (1 - cosA);   // ala Schlick interpoliation
			     return F0 + (1-F0) * t;
			 }

			 float3 FresnelLerp (float3 F0, float3 F90, float cosA)
			 {
				 float t = Pow5 (1 - cosA);   // ala Schlick interpoliation
				 return lerp (F0, F90, t);
			 }

			 /////////V
			 float SmithJointGGXVisibilityTerm (float NdotL, float NdotV, float roughness)
			  {

				 float a = roughness;
				 float lambdaV = NdotL * (NdotV * (1 - a) + a);
				 float lambdaL = NdotV * (NdotL * (1 - a) + a);
				 return 0.5f / (lambdaV + lambdaL + 1e-5f);

			 }


			 ///////D
			 float GGXTerm (float NdotH, float roughness)
			 {
				 float a2 = roughness * roughness;
				 float d = (NdotH * a2 - NdotH) * NdotH + 1.0f; 
				 return (1/PI) * a2 / (d * d + 1e-7f); 
			 }

			 ////////D

			 float NDFBlinnPhongNormalizedTerm (float NdotH, float smoothness)
		 {

		float perceptualRoughness = (1 - smoothness);
		 float m = perceptualRoughness * perceptualRoughness;
			 
			 float sq = max(1e-4f, m*m);
			 float n = (2.0 / sq) - 2.0;   
			 n = max(n, 1e-4f);

			 float normTerm = (n + 2.0) * (0.5/PI);
			 float specTerm = pow (NdotH, n);
			 return specTerm * normTerm;
		 }

		 float SmoothnessToPerceptualRoughness(float smoothness)
		 {
			 return (1 - smoothness);
		 }

		 float PerceptualRoughnessToRoughness(float perceptualRoughness)
		 {
			 return perceptualRoughness * perceptualRoughness;
		 }

			 ///////disney
			 float DisneyDiffuse(float NdotV, float NdotL, float LdotH, float perceptualRoughness)
			 {
				 float fd90 = 0.5 + 2 * LdotH * LdotH * perceptualRoughness;
				 float lightScatter   = (1 + (fd90 - 1) * Pow5(1 - NdotL));
				 float viewScatter    = (1 + (fd90 - 1) * Pow5(1 - NdotV));
 
				 return lightScatter * viewScatter;
			 }


			 			  float OneMinusReflectivityFromMetallic(float metallic)
			{
				float oneMinusDielectricSpec = ColorSpaceDielectricSpec.a;
				return oneMinusDielectricSpec - metallic * oneMinusDielectricSpec;
			}

			float3 DiffuseAndSpecularFromMetallic (float3 albedo, float metallic)
			{
				float3 specColor = lerp (ColorSpaceDielectricSpec.rgb, albedo, metallic);
				float oneMinusReflectivity = OneMinusReflectivityFromMetallic(metallic);
				return albedo * oneMinusReflectivity;
			}


void fp_main_pbr(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D albedoTex : register(s0),
      	uniform sampler2D metallicTex 	: register(s1),
      	uniform sampler2D normalTex 	: register(s2),
    #endif
    
	   	  in float3 normal : TEXCOORD2,
	      in float3 viewDir	: TEXCOORD3,
	      in float3 tangent : TEXCOORD4,
		    in float3 pos : TEXCOORD5,
		    in float3 bitangent : TEXCOORD6,
		    
		    
    #if LIGHT_ENABLE
    		uniform float4 derived_scene_colour,
    		uniform float4 surface_diffuse_colour,
        uniform float4 light_position_array[NUM_LIGHTS],
		    uniform float4 light_attenuation_array[NUM_LIGHTS],         
		    uniform float4 derived_light_diffuse_colour_array[NUM_LIGHTS],
		    
		    uniform float4 actor_ambient_params,
		    uniform float4 actor_lightone_params,
		    uniform float4 actor_lighttwo_params,
		    uniform float4 userflag,
    #endif
    
    #if ENABLE_SPHEREMAPPING_TEX
				uniform sampler2D sphereMappingTex : register(s1),
    #endif
    		
    		uniform float4 fog_type,
    		uniform float4 fog_params,
    		uniform float4 fog_colour,
    		uniform float4x4 view_matrix,
    		//uniform float4 tex0BlendColor,
    		uniform float4 multiBlendColor,
	
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);

  	float4 albedoTexVar = float4(0.0,0.0,0.0,1.0);
		float4 metallicTexVar = float4(0.0,0.0,0.0,1.0);
		float4 normalTexVar = float4(0.0,0.0,0.0,1.0);

		#if NUM_TEXCOORDS > 0
			
			albedoTexVar = tex2D(albedoTex, uv.xy);
			metallicTexVar = tex2D(metallicTex, uv.xy);
			normalTexVar = tex2D(normalTex, uv.xy);
			
			normalTexVar.g = 1 - normalTexVar.g;
			
    #endif
    
    #if LIGHT_ENABLE
    
		  normal.r = - normal.r;
			tangent.r = - tangent.r;
			viewDir.x = - viewDir.x;
		  float3 normalDir = normalize(normal);
		  float3 viewDirection = normalize(viewDir);
			float3x3 tangentTransform = float3x3( tangent, bitangent, normal);//���ߵ�TBN��ת����
		  float3 normalLocal = normalTexVar.rgb * 2 - 1;
		  float3 normalDirection = normalize(mul( normalLocal, tangentTransform )); // ���յķ���
		  normalDirection.r = - normalDirection.r;
		  float Metallic = metallicTexVar.r; 
		  float smoothness =  1 - saturate((metallicTexVar.g));  	
		  float skin = metallicTexVar.b;
		  float4 lightPosition[NUM_LIGHTS+1];
    	float4 lightAttenuation[NUM_LIGHTS+1];    
      float4 diffuseColour[NUM_LIGHTS+1]; 
      
    	diffuseColour[0] = derived_light_diffuse_colour_array[0] * (1.0 - userflag.x) + actor_lightone_params * surface_diffuse_colour * userflag.x;
			diffuseColour[1] = derived_light_diffuse_colour_array[1] * (1.0 - userflag.x) + actor_lighttwo_params * surface_diffuse_colour * userflag.x;
			diffuseColour[2] = derived_light_diffuse_colour_array[2];
			diffuseColour[3] = float4(200/255.0,200/255.0,200/255.0,1.0);
			
			lightPosition[0] = light_position_array[0];
	    lightPosition[1] = light_position_array[1]; 
	    lightPosition[2] = light_position_array[2];
	    lightPosition[3] = float4(viewDirection,0);
	    
		  lightAttenuation[0] = light_attenuation_array[0];
	    lightAttenuation[1] = light_attenuation_array[1];   
	    lightAttenuation[2] = light_attenuation_array[2];
	    lightAttenuation[3] = light_attenuation_array[0];
      
      float3 indirectDiffuse = float3(0,0,0);
    	indirectDiffuse += 0.5 * derived_scene_colour * (1.0 - userflag.x) + actor_ambient_params * userflag.x; // Ambient Light     
 	    float4 finalcolor = float4(0.0,0.0,0.0,1.0);
 	    
 	    float perceptualRoughness = SmoothnessToPerceptualRoughness (smoothness);
			float roughness = PerceptualRoughnessToRoughness(perceptualRoughness);
		  roughness = max(roughness, 0.002);
		  float3 specColor = lerp (ColorSpaceDielectricSpec.rgb, albedoTexVar, Metallic);
		  float3 specColorWithIndirect = lerp (ColorSpaceDielectricSpec.rgb, albedoTexVar + indirectDiffuse, Metallic);
		  float oneMinusReflectivity = OneMinusReflectivityFromMetallic(Metallic);
      
      float nv = abs(dot(normalDirection, viewDirection));
			float3 diffuse[NUM_LIGHTS+1];
			float3 specular[NUM_LIGHTS+1];
			float3 kk[NUM_LIGHTS+1];
			

			
			for (int l = 0; l < NUM_LIGHTS + 1; ++l)
	    {
				float3 lightDir = lightPosition[l].xyz - (pos * lightPosition[l].w);
				float3 lightDirection = normalize(lightPosition[l].xyz - (pos * lightPosition[l].w));
				float lightDirLength = length(lightDir);
				float att = lerp(0, 1, 1 / dot(float3(1, lightDirLength, lightDirLength*lightDirLength), lightAttenuation[l].yzw));
   		float3 attenColor = (max(max(max(diffuseColour[l].r,diffuseColour[l].g),diffuseColour[l].b),0.2).xxx) * saturate(att);
    		
	      float3 halfDir = normalize (lightDirection + viewDirection);
	      
				float nl = saturate(dot(normalDirection, lightDirection));
      	float nh = saturate(dot(normalDirection, halfDir));
     		float lv = saturate(dot(lightDirection, viewDirection));
     		float lh = saturate(dot(lightDirection, halfDir));
				float diffuseTerm = DisneyDiffuse(nv, nl, lh, perceptualRoughness) * nl;
				float V = SmithJointGGXVisibilityTerm (nl, nv, roughness);
				float D = GGXTerm (nh, roughness);
				float specularTerm = V*D * PI;

				specularTerm = sqrt(max(1e-4h, specularTerm));
				specularTerm = max(0, specularTerm * nl);
				specularTerm *= any(specColor) ? 1.0 : 0.0;
				
				diffuse[l] =  attenColor *  diffuseTerm;
				specular[l] = specularTerm * attenColor * FresnelTerm (specColor, lh);
				kk[l] = acos(lv) / PI;
				
	    }	
	
			float surfaceReduction;
      surfaceReduction = 1.0-0.28*roughness*perceptualRoughness; 
			float grazingTerm = saturate(smoothness + (1-oneMinusReflectivity));
			
			float k = kk[1] * 0.5 + 0.55;

		 
		 	finalcolor.rgb =   albedoTexVar * ((diffuse[0] * 0.2 + diffuse[1] * 0.2 + diffuse[2] * 0.3 + diffuse[3] *k + indirectDiffuse * 0.2)) * (1-Metallic +0.04) * surface_diffuse_colour
												+ specular[0] * 0.4 + specular[1] * 0.4 + specular[2] * 0.3 + specular[3] *k
												+ surfaceReduction * FresnelLerp (specColorWithIndirect, grazingTerm, nv)* 0.3;
												
		//	finalcolor.rgb =   albedoTexVar * ((diffuse[0] * 0.5 + diffuse[1] * 0.5 + diffuse[2] + diffuse[3] * 0.85 + indirectDiffuse * 0.3)) * (1-Metallic +0.04) * surface_diffuse_colour
		//										+ specular[0] * 0.5  + specular[1] * 0.5 + specular[2] * 0.5 + specular[3] * 0.6
		//										+ surfaceReduction * FresnelLerp (specColorWithIndirect, grazingTerm, nv)* 0.1;
												
		float grey = 0.2125 * finalcolor.r + 0.7154 * finalcolor.g + 0.0721 * finalcolor.b;
		float3 greys = (grey, grey ,grey);
		finalcolor.rgb = lerp(greys, finalcolor.rgb, 1.1);
		
		
    
    
    float3 oldColor = float3(0.0,0.0,0.0);
    float3 LightDiffuse = float3(0.0,0.0,0.0);
    for (int l = 0; l < NUM_LIGHTS; ++l)
    {
    
    		float3 lightDir = lightPosition[l].xyz - (pos * lightPosition[l].w);
				float3 lightDirection = normalize(lightPosition[l].xyz - (pos * lightPosition[l].w));
				float lightDirLength = length(lightDir);
				float att = lerp(0, 1, 1 / dot(float3(1, lightDirLength, lightDirLength*lightDirLength), lightAttenuation[l].yzw));
    		float3 attenColor = diffuseColour[l].rgb;

    		float fNdotL = dot(normalDir, lightDirection);

       LightDiffuse += att * max(fNdotL, 0) * diffuseColour[l].rgb;
     }
    
    oldColor.rgb = albedoTexVar.rgb * saturate(LightDiffuse + indirectDiffuse.rgb);

		
		
		oColour.rgb =  1.03 * (oldColor.rgb * skin + finalcolor.rgb * (1 - skin));
	
		#endif
    
    #if ENABLE_SPHEREMAPPING_TEX
  		float4 sphereTexColor = float4(0.0, 0.0, 0.0, 1.0);
  		float2 sphereTexUV = normalize(mul(view_matrix, float4(normal, 0.0))).xy*0.5 + 0.5;
  		sphereTexColor = tex2D(sphereMappingTex, sphereTexUV);
  		oColour.xyz = (oColour.xyz + sphereTexColor.xyz) - oColour.xyz * sphereTexColor.xyz;
		#endif
		
		
		// cal fog
	  float4 posInView = mul(view_matrix, float4(pos.xyz, 1.0));
	  
	  oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
	
		oColour.rgb *= multiBlendColor.xyz * multiBlendColor.w;
		
		oColour.a = surface_diffuse_colour.a * albedoTexVar.a;

}
