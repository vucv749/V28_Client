/////////////////////////////////////// vp_main //////////////////////////////////
#ifndef MAX_WORLD_MATRICES
    #define MAX_WORLD_MATRICES	25
#endif

#ifndef MAX_BLEND_WEIGHTS
    #define MAX_BLEND_WEIGHTS	1
#endif


#ifndef FLOW_LIGHT_TYPE
    #define FLOW_LIGHT_TYPE	0
#endif

#ifndef USE_LAST_WEIGHT
    #if MAX_BLEND_WEIGHTS != 3
        #define USE_LAST_WEIGHT     1
    #else
        #define USE_LAST_WEIGHT     0
    #endif
#endif

#ifndef NUM_TEXCOORDS
    #define NUM_TEXCOORDS       1
#endif

#if NUM_TEXCOORDS > 0

    #define ORIGINAL_TEXCOORD   0
    #define SINGLE_TEXCOORD     1
    #define PROJECTION_TEXCOORD 2

    #ifndef TEXCOORD_SOURCE
        #define TEXCOORD_SOURCE     ORIGINAL_TEXCOORD
    #endif

#endif

#ifndef LIGHTING_AMBIENT
    #define LIGHTING_AMBIENT    0
#endif

#ifndef NUM_LIGHTS
    #define NUM_LIGHTS          0
#endif

#if NUM_LIGHTS > 0
    
    //#ifndef ENABLE_SPECULAR
    //    #define ENABLE_SPECULAR     1
    //#endif
    
    #define ARBITRARY_LIGHT     0
    #define DIRECTIONAL_LIGHT   1
    #define POINT_LIGHT         2

    #ifndef LIGHT_TYPE
        #define LIGHT_TYPE          ARBITRARY_LIGHT
    #endif

#endif

#ifndef USE_TANGENT
    #define USE_TANGENT          0
#endif

#ifndef USE_VERTEXCOLOR
    #define USE_VERTEXCOLOR          0
#endif

#ifndef LIGHT_ENABLE
    #define LIGHT_ENABLE          1
#endif

#ifndef TEX_EFFECT_0
	#define TEX_EFFECT_0 0
#endif

#ifndef TEX_EFFECT_1
	#define TEX_EFFECT_1 0
#endif

#ifndef ENABLE_DIFFUSE_2
	#define ENABLE_DIFFUSE_2 0
#endif

#define BLEND_OP_MODULATE   0
#define BLEND_OP_MODULATE2     1
#define BLEND_OP_MODULATE4     2
#define BLEND_OP_ADD     3
#define BLEND_OP_CUSTOM     4

// process the ColorOp of texUnit0
#if NUM_TEXCOORDS > 0
	#ifndef BLEND_OP_0
			#define BLEND_OP_0 BLEND_OP_MODULATE
	#endif
#endif

// process the ColorOp of texUnit1
#if ENABLE_DIFFUSE_2 > 0
	#ifndef BLEND_OP_1
			#define BLEND_OP_1 BLEND_OP_MODULATE
	#endif
#endif

#ifndef USE_TEXLOD0
	#define USE_TEXLOD0 0
#endif



void vp_main(
            in float4 position : POSITION,
            in int4 blendIndex : BLENDINDICES,

            #if MAX_BLEND_WEIGHTS > 1
                in float4 blendWeight : BLENDWEIGHT,
            #endif

            out float4 oPosition : POSITION,

            #if LIGHTING_AMBIENT || NUM_LIGHTS
                out float4 oColour : COLOR0,

                #if LIGHTING_AMBIENT
                    uniform float4 derived_scene_colour,
                #endif

                #if NUM_LIGHTS
		                in float3 normal : NORMAL,
		               	#if USE_TANGENT
		                	in float3 tangent : TANGENT,
		                #endif
		                #if USE_VERTEXCOLOR
		                	in float4 vColor : COLOR0,
		                #endif
		                
		                uniform float4 light_position_array[NUM_LIGHTS],
		
		                #if LIGHT_TYPE != DIRECTIONAL_LIGHT
		                    uniform float4 light_attenuation_array[NUM_LIGHTS],
		                #endif
		                    
		                uniform float4 cameraPos,
		                uniform float4 surface_diffuse_colour,
		                uniform float4 derived_light_diffuse_colour_array[NUM_LIGHTS],
		                
		                uniform float4 actor_ambient_params,
		                uniform float4 actor_lightone_params,
		                uniform float4 actor_lighttwo_params,
		                uniform float4 userflag,
												
										//#if ENABLE_SPECULAR
										out float3 oNormal : TEXCOORD2,
		                out float3 oViewDir : TEXCOORD3, 
		                out float3 oLightDir : TEXCOORD4,
		                out float3 oTangent : TEXCOORD5,
		                out float3 oPosInWorld : TEXCOORD7,
		                out float3 oOldNormal : TEXCOORD6,
		                //#endif
		            #endif

            #endif

            #if NUM_TEXCOORDS > 0
               			#if TEX_EFFECT_0
                        uniform float4x4 textureTransMatrix0,
                    #endif
                    #if TEX_EFFECT_1
                    		uniform float4x4 textureTransMatrix1,
                    #endif
                				in float4 uv0 : TEXCOORD0,
                        out float4 oTexcoords : TEXCOORD0,
                        out float4 oUVExtern : TEXCOORD1,
            #endif            

            uniform float4x4 viewproj_matrix,
            uniform float3x4 worldMatrix3x4Array[MAX_WORLD_MATRICES] )
{
    // transform to world space by indexed matrices
    float3 blendPos = float3(0,0,0);

#if NUM_LIGHTS
    // transform normal to world space by indexed matrices
    float3 blendNorm = float3(0,0,0);
    float3 blendTanget = float3(0,0,0);
#endif

#if USE_LAST_WEIGHT
    // Use this to avoid weight by last component of blendWeights, which
    // maybe wrong when number of weights equal four.
    float lastWeight = 1;

    #if MAX_BLEND_WEIGHTS > 1
        for (int i = 0; i < MAX_BLEND_WEIGHTS-1; ++i)
        {
            lastWeight -= blendWeight[i];
            blendPos += mul(worldMatrix3x4Array[blendIndex[i]], position) * blendWeight[i];
            
            #if NUM_LIGHTS
                blendNorm += mul( (float3x3)worldMatrix3x4Array[blendIndex[i]], normal ) * blendWeight[i];
                #if USE_TANGENT
                	blendTanget += mul( (float3x3)worldMatrix3x4Array[blendIndex[i]], tangent ) * blendWeight[i];
                #endif
            #endif
        }
    #endif
		lastWeight = step(0.001, lastWeight) * lastWeight;
    blendPos += mul(worldMatrix3x4Array[blendIndex[MAX_BLEND_WEIGHTS-1]], position) * lastWeight;
    
    #if NUM_LIGHTS
        blendNorm += mul( (float3x3)worldMatrix3x4Array[blendIndex[MAX_BLEND_WEIGHTS-1]], normal ) * lastWeight;
        #if USE_TANGENT
        	blendTanget += mul( (float3x3)worldMatrix3x4Array[blendIndex[MAX_BLEND_WEIGHTS-1]], tangent ) * lastWeight;
        #endif
    #endif

#else // !USE_LAST_WEIGHT

    for (int i = 0; i < MAX_BLEND_WEIGHTS; ++i)
    {
        blendPos += mul(worldMatrix3x4Array[blendIndex[i]], position)
        #if MAX_BLEND_WEIGHTS > 1
            * blendWeight[i]
        #endif
            ;

        #if NUM_LIGHTS
            blendNorm += mul((float3x3)worldMatrix3x4Array[blendIndex[i]], normal)
            #if MAX_BLEND_WEIGHTS > 1
                * blendWeight[i]
            #endif
                ;
            #if USE_TANGENT
	            blendTanget += mul((float3x3)worldMatrix3x4Array[blendIndex[i]], tangent)
	            #if MAX_BLEND_WEIGHTS > 1
	                * blendWeight[i]
	            #endif
	                ;
            #endif
        #endif
    }
#endif // USE_LAST_WEIGHT

    // view / projection
    oPosition = mul( viewproj_matrix, float4(blendPos, 1.0) );

#if NUM_TEXCOORDS > 0
    // Calculate texcoords
    #if TEX_EFFECT_0
    	oTexcoords = mul( textureTransMatrix0, uv0 );
    #else
    	oTexcoords = uv0;
    #endif
    #if TEX_EFFECT_1
    	oUVExtern = mul( textureTransMatrix1, uv0 );
    #else
    	oUVExtern = uv0;
		#endif
#endif

#if LIGHTING_AMBIENT
    oColour = derived_scene_colour;
#endif

#if NUM_LIGHTS
		oPosInWorld = blendPos.xyz;
		oOldNormal = normal;
    blendNorm = normalize(blendNorm);
    #if USE_TANGENT
    	blendTanget = normalize(float4(blendTanget, 1.0)).xyz;
    #endif
    
    oColour = derived_scene_colour * (1.0 - userflag.x) + actor_ambient_params * userflag.x;

		float4 lightDiffuseColor[NUM_LIGHTS];
		lightDiffuseColor[0] = derived_light_diffuse_colour_array[0] * (1.0 - userflag.x) + actor_lightone_params * surface_diffuse_colour * userflag.x;
		lightDiffuseColor[1] = derived_light_diffuse_colour_array[1] * (1.0 - userflag.x) + actor_lighttwo_params * surface_diffuse_colour * userflag.x;
		lightDiffuseColor[2] = derived_light_diffuse_colour_array[2];
		
		#if USE_VERTEXCOLOR
    	oColour.a *= vColor.a;
    	lightDiffuseColor[0].rgb *= vColor.rgb;
			lightDiffuseColor[1].rgb *= vColor.rgb;
			lightDiffuseColor[2].rgb *= vColor.rgb;
    #endif
		
    #if !LIGHTING_AMBIENT
        oColour = float4(0, 0, 0, lightDiffuseColor[0].a);
    #endif

        for (int l = 0; l < NUM_LIGHTS; ++l)
        {
    #if LIGHT_TYPE == DIRECTIONAL_LIGHT
            // Lighting - support directional light only
            float3 lightDir = light_position_array[l].xyz;
    #elif LIGHT_TYPE == POINT_LIGHT
            // Lighting - support point light only
            float3 lightDir = light_position_array[l].xyz - blendPos;
    #else
            // Lighting - support point and directional light
            float3 lightDir = light_position_array[l].xyz - (blendPos * light_position_array[l].w);
    #endif
            float d = length(lightDir);
            lightDir /= d;

            float ndotl = dot(blendNorm, lightDir);
    //#if ENABLE_SPECULAR
    				if (l == 0)
		        {
		            oNormal = blendNorm;
		            oLightDir = lightDir;
		     				oViewDir = cameraPos.xyz - blendPos.xyz;
		     				oTangent = blendTanget;
		        }
		//#endif
            float3 colour = max(ndotl, 0) * lightDiffuseColor[l].rgb;
    
    #if LIGHT_TYPE == DIRECTIONAL_LIGHT
            float att = 1;
    #elif LIGHT_TYPE == POINT_LIGHT
            float att = 1 / (light_attenuation_array[l].y + d * (light_attenuation_array[l].z + d * light_attenuation_array[l].w));
    #else
            float att = lerp(0, 1, 1 / dot(float3(1, d, d*d), light_attenuation_array[l].yzw));
    #endif

            oColour.rgb += att * colour;
        }
        oColour.rgb = saturate(oColour.rgb);
#endif

}

/////////////////////////////////////// fp_main //////////////////////////////////

float3 Fogging(float3 finalColour, float depthInView, float4 fogType, float4 fogParam, float4 fogColor)
{
		float fogFactor = 0.0;
		fogFactor += fogType[0];
		fogFactor += fogType[1] * exp(- depthInView * fogParam.x);
		fogFactor += fogType[2] * exp(- (depthInView * fogParam.x) * (depthInView * fogParam.x));
		fogFactor += fogType[3] * saturate((fogParam.z - depthInView) * fogParam.w);
		float3 color = finalColour.rgb * fogFactor + fogColor.rgb * (1 - fogFactor);
		return color;
}


void fp_main(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D baseTex : register(s0),
      #if ENABLE_DIFFUSE_2
      		uniform sampler2D diffuse2Tex : register(s1),
      	#if BLEND_OP_1 == BLEND_OP_CUSTOM
      		uniform sampler2D blend2Tex 	: register(s2),
      	#endif
      #endif
    #endif
    
    		in float4 colour		: COLOR0,
    	  in float3 normal : TEXCOORD2,
	      in float3 viewDir	: TEXCOORD3,
	      in float3 lightDir : TEXCOORD4,
	      in float3 tangent : TEXCOORD5,
		  in float3 posInWorld : TEXCOORD7,
		  in float3 oldNormal : TEXCOORD6,
    #if LIGHT_ENABLE
    		uniform float4 surface_specular_colour,
        uniform float  surface_shininess,
        uniform float4 lightSpecular0,		
    #endif
    
    #if ENABLE_SPHEREMAPPING_TEX
				uniform sampler2D sphereMappingTex : register(s1),
    #endif
    		
    		uniform float4 fog_type,
    		uniform float4 fog_params,
    		uniform float4 fog_colour,
    		uniform float4x4 view_matrix,
    		uniform float4 tex0BlendColor,
    		uniform float4 multiBlendColor,
	
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);
    
		#if NUM_TEXCOORDS > 0
			
			#if LIGHT_ENABLE
				float4 stageColor = colour;
			#else
				float4 stageColor = float4(1.0,1.0,1.0,colour.w);
			#endif
			stageColor.xyz = stageColor.xyz * (1-tex0BlendColor.w) + tex0BlendColor.xyz * tex0BlendColor.w;
			#if USE_TEXLOD0
				float4 baseTexColour = tex2Dlod(baseTex, float4(uv.xy,0,0));
			#else
				float4 baseTexColour = tex2D(baseTex, uv.xy);				
			#endif

      #if BLEND_OP_0 == 1
      	stageColor.xyz *= baseTexColour.xyz * 2.0;
    	#elif BLEND_OP_0 == 2
      	stageColor.xyz *= baseTexColour.xyz * 4.0;
    	#elif BLEND_OP_0 == 3
      	stageColor.xyz += baseTexColour.xyz;
    	#else
    		stageColor.xyz *= baseTexColour.xyz;
    	#endif
    	stageColor.w *= baseTexColour.w;
      
      #if ENABLE_DIFFUSE_2
				float4 diffuse2TexColour = tex2D(diffuse2Tex, uvExtern.xy);
      	#if BLEND_OP_1 == 1
      		stageColor.xyz *= diffuse2TexColour.xyz * 2.0;
      	#elif BLEND_OP_1 == 2
      		stageColor.xyz *= diffuse2TexColour.xyz * 4.0;
      	#elif BLEND_OP_1 == 3
      		stageColor.xyz += diffuse2TexColour.xyz;
      	#elif BLEND_OP_1 == 4
      		float factor = tex2D( blend2Tex, uv.xy ).r;
      		stageColor.xyz = lerp( stageColor.xyz, diffuse2TexColour.xyz, factor );
      	#else
      		stageColor.xyz *= diffuse2TexColour.xyz;
      	#endif
      	stageColor.w *= diffuse2TexColour.w;
			#endif

			oColour = stageColor;

    #else
        oColour.xyz += colour.xyz;
        oColour.w += colour.w;
    #endif
    
    
    #if LIGHT_ENABLE
    float3 Nn = normalize(normal);
		float3 Ln = normalize(lightDir);
		float3 Vn = normalize(viewDir);
		float3 Hn = normalize(Vn + Ln);
		float3 Tn = normalize(float4(tangent, 1.0)).xyz;
		
    // calculate specular color
		float specularLight = pow(max(dot(Nn, Hn), 0.01), surface_shininess);
		float3 specular = surface_specular_colour.xyz * specularLight * lightSpecular0.xyz;
		oColour.xyz += specular.xyz;
		//oColour.w *= lightOneColour.w;
		#endif
    
    #if ENABLE_SPHEREMAPPING_TEX
			// add environment texture color
  		float4 sphereTexColor = float4(0.0, 0.0, 0.0, 1.0);
  		float2 sphereTexUV = normalize(mul(view_matrix, float4(normal, 0.0))).xy*0.5 + 0.5;
  		sphereTexColor = tex2D(sphereMappingTex, sphereTexUV);
  		oColour.xyz = (oColour.xyz + sphereTexColor.xyz) - oColour.xyz * sphereTexColor.xyz;
		#endif
		// cal fog
	  float4 posInView = mul(view_matrix, float4(posInWorld.xyz, 1.0));
	  oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
		
		oColour.xyz *= multiBlendColor.xyz * multiBlendColor.w;
		
}
void fp_embient_main(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D baseTex : register(s0),      
    #endif
    
    		in float4 colour		: COLOR0,
    	  in float3 normal : TEXCOORD2,
	      in float3 viewDir	: TEXCOORD3,
	      in float3 lightDir : TEXCOORD4,
	      in float3 tangent : TEXCOORD5,
		  in float3 posInWorld : TEXCOORD7,
		  in float3 oldNormal : TEXCOORD6,
    #if LIGHT_ENABLE
    		uniform float4 surface_specular_colour,
        uniform float  surface_shininess,
        uniform float4 lightSpecular0,		
    #endif
    
    #if ENABLE_SPHEREMAPPING_TEX
				uniform sampler2D sphereMappingTex : register(s1),
    #endif
    		
    		uniform float4 fog_type,
    		uniform float4 fog_params,
    		uniform float4 fog_colour,
    		uniform float4x4 view_matrix,
    		uniform float4 tex0BlendColor,
    		uniform float4 multiBlendColor,
	
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);
    
		#if NUM_TEXCOORDS > 0
			
			#if LIGHT_ENABLE
				float4 stageColor = colour;
			#else
				float4 stageColor = float4(1.0,1.0,1.0,colour.w);
			#endif
			stageColor.xyz = stageColor.xyz * (1-tex0BlendColor.w) + tex0BlendColor.xyz * tex0BlendColor.w;
			#if USE_TEXLOD0
				float4 baseTexColour = tex2Dlod(baseTex, float4(uv.xy,0,0));
			#else
				float4 baseTexColour = tex2D(baseTex, uv.xy);				
			#endif

      #if BLEND_OP_0 == 1
      	stageColor.xyz *= baseTexColour.xyz * 2.0;
    	#elif BLEND_OP_0 == 2
      	stageColor.xyz *= baseTexColour.xyz * 4.0;
    	#elif BLEND_OP_0 == 3
      	stageColor.xyz += baseTexColour.xyz;
    	#else
    		stageColor.xyz *= baseTexColour.xyz;
    	#endif
    	stageColor.w *= baseTexColour.w;
           

			oColour = stageColor;

    #else
        oColour.xyz += colour.xyz;
        oColour.w += colour.w;
    #endif
    
    
    #if LIGHT_ENABLE
    float3 Nn = normalize(normal);
		float3 Ln = normalize(lightDir);
		float3 Vn = normalize(viewDir);
		float3 Hn = normalize(Vn + Ln);
		float3 Tn = normalize(float4(tangent, 1.0)).xyz;
		
    // calculate specular color
		float specularLight = pow(max(dot(Nn, Hn), 0.01), surface_shininess);
		float3 specular = surface_specular_colour.xyz * specularLight * lightSpecular0.xyz;
		oColour.xyz += specular.xyz;
		//oColour.w *= lightOneColour.w;
		#endif
    
    #if ENABLE_SPHEREMAPPING_TEX
			// add environment texture color
  		float4 sphereTexColor = float4(0.0, 0.0, 0.0, 1.0);
  		float2 sphereTexUV = normalize(mul(view_matrix, float4(normal, 0.0))).xy*0.5 + 0.5;
  		sphereTexColor = tex2D(sphereMappingTex, sphereTexUV);
  		oColour.xyz = (oColour.xyz + sphereTexColor.xyz) - oColour.xyz * sphereTexColor.xyz;
		#endif
		// cal fog
	  float4 posInView = mul(view_matrix, float4(posInWorld.xyz, 1.0));
	  oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
		
		oColour.xyz *= multiBlendColor.xyz * multiBlendColor.w;
		
}

void fp_highlight_simple_main(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D baseTex : register(s0),
      	uniform sampler2D ctlTex : register(s1),
    #endif
    
    		in float4 colour		: COLOR0,
    	  in float3 normal : TEXCOORD2,
	      in float3 viewDir	: TEXCOORD3,
	      in float3 lightDir : TEXCOORD4,
	      in float3 tangent : TEXCOORD5,
		  in float3 posInWorld : TEXCOORD7,
		  in float3 oldNormal : TEXCOORD6,
    #if LIGHT_ENABLE
    		uniform float4 surface_specular_colour,
        uniform float  surface_shininess,
        uniform float4 lightSpecular0,		
    #endif
    
    #if ENABLE_SPHEREMAPPING_TEX
				uniform sampler2D sphereMappingTex : register(s1),
    #endif
    		
    		uniform float4 fog_type,
    		uniform float4 fog_params,
    		uniform float4 fog_colour,
    		uniform float4x4 view_matrix,
    		uniform float4 tex0BlendColor,
    		uniform float4 multiBlendColor,
	
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);
    
		#if NUM_TEXCOORDS > 0
			
			#if LIGHT_ENABLE
				float4 stageColor = colour;
			#else
				float4 stageColor = float4(1.0,1.0,1.0,colour.w);
			#endif
			stageColor.xyz = stageColor.xyz * (1-tex0BlendColor.w) + tex0BlendColor.xyz * tex0BlendColor.w;
			#if USE_TEXLOD0
				float4 baseTexColour = tex2Dlod(baseTex, float4(uv.xy,0,0));
			#else
				float4 baseTexColour = tex2D(baseTex, uv.xy);				
			#endif

      #if BLEND_OP_0 == 1
      	stageColor.xyz *= baseTexColour.xyz * 2.0;
    	#elif BLEND_OP_0 == 2
      	stageColor.xyz *= baseTexColour.xyz * 4.0;
    	#elif BLEND_OP_0 == 3
      	stageColor.xyz += baseTexColour.xyz;
    	#else
    		stageColor.xyz *= baseTexColour.xyz;
    	#endif
    	stageColor.w *= baseTexColour.w;

			oColour = stageColor;

    #else
        oColour.xyz += colour.xyz;
        oColour.w += colour.w;
    #endif
    
    
    
    #if LIGHT_ENABLE
    float3 Nn = normalize(normal);
		float3 Ln = normalize(lightDir);
		float3 Vn = normalize(viewDir);
		float3 Hn = normalize(Vn + Ln);
		float3 Tn = normalize(float4(tangent, 1.0)).xyz;
		
    // calculate specular color
		float specularLight = pow(max(dot(Nn, Hn), 0.01), surface_shininess);
		float3 specular = surface_specular_colour.xyz * specularLight * lightSpecular0.xyz;
		
		float4 ctlColour = tex2D(ctlTex, uv.xy);
		oColour.xyz += specular.xyz * ctlColour.xyz;
		#endif
    
    #if ENABLE_SPHEREMAPPING_TEX
			// add environment texture color
  		float4 sphereTexColor = float4(0.0, 0.0, 0.0, 1.0);
  		float2 sphereTexUV = normalize(mul(view_matrix, float4(normal, 0.0))).xy*0.5 + 0.5;
  		sphereTexColor = tex2D(sphereMappingTex, sphereTexUV);
  		oColour.xyz = (oColour.xyz + sphereTexColor.xyz) - oColour.xyz * sphereTexColor.xyz;
		#endif
		// cal fog
	  float4 posInView = mul(view_matrix, float4(posInWorld.xyz, 1.0));
	  oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
		
		oColour.xyz *= multiBlendColor.xyz * multiBlendColor.w;
}


//vp highlight  fp
void fp_highlight_main(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D baseTex : register(s0),            	  	
		uniform sampler2D ctlTex : register(s1),    
		uniform sampler2D _Reflection : register(s2),    
    #endif    
    	in float4 colour		: COLOR0,
    	in float3 normal : TEXCOORD2,
	    in float3 viewDir	: TEXCOORD3,
	    in float3 lightDir : TEXCOORD4,   
	    in float3 posInWorld : TEXCOORD7,
	    in float3 oldNormal : TEXCOORD6,
		#if LIGHT_ENABLE      
        uniform float4 lightSpecular0,		
    #endif 
		uniform float4 fog_type,
    	uniform float4 fog_params,
    	uniform float4 fog_colour,
    	uniform float4x4 view_matrix,
		uniform float4 tex0BlendColor,
    	uniform float4 multiBlendColor,
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);    
	#if NUM_TEXCOORDS > 0			
		#if LIGHT_ENABLE
			float4 stageColor = colour;
		#else
			float4 stageColor = float4(1.0,1.0,1.0,colour.w);
		#endif			
		float4 baseTexColour = tex2D(baseTex, uv.xy);     
		stageColor.xyz = stageColor.xyz * (1-tex0BlendColor.w) + tex0BlendColor.xyz * tex0BlendColor.w;
    	stageColor *= baseTexColour;    	    		      
		oColour = stageColor;
    #else
        oColour.xyz += colour.xyz;
        oColour.w += colour.w;
    #endif      
		
    #if LIGHT_ENABLE  
    float3 Nn = normalize(normal);
		float3 Ln = normalize(lightDir);
		float3 Vn = normalize(viewDir);
		float3 Hn = normalize(Vn + Ln);
		 		
		float rimRange = 1-abs(dot(Vn,Nn));
        float4 CtrlTex = tex2D(ctlTex,uv.xy);			
		float2 ReflUV = normalize(mul(view_matrix, float4(normal, 0.0))).xy*0.5 + 0.5;        					
		float4 _Reflection_var = tex2D(_Reflection,ReflUV);
		//�߹�
		float3 emissive = _Reflection_var.xyz*CtrlTex.x;
		//�߹�Ĳ��� ��������Ҫ��Ȼ����ʾ������
		float3 emissive3 = rimRange*rimRange*lightSpecular0.xyz * CtrlTex.x;
		//emissive�Ĳ���
		float3 emissive4 = baseTexColour.xyz*CtrlTex.g;
		oColour.xyz += emissive;		
		oColour.xyz += emissive3;		
		oColour.xyz += emissive4;
	#endif        	
	// cal fog
	float4 posInView = mul(view_matrix, float4(posInWorld.xyz, 1.0));
	oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
	   	
	oColour.xyz *= multiBlendColor.xyz * multiBlendColor.w;
}
//flowlight fp
void fp_flowlight_main(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D baseTex : register(s0),      
      	uniform sampler2D ctlTex : register(s1),    
		uniform sampler2D _Reflection : register(s2),         
    #endif
    
    	in float4 colour		: COLOR0,
    	in float3 normal : TEXCOORD2,
	    in float3 viewDir	: TEXCOORD3,
	    in float3 lightDir : TEXCOORD4,
	    in float3 posInWorld : TEXCOORD7,
	    in float3 oldNormal : TEXCOORD6,
    #if LIGHT_ENABLE
    	uniform float4 surface_specular_colour,
        uniform float  surface_shininess,
        uniform float4 lightSpecular0,		
    #endif       		
		uniform float4 fog_type,
    	uniform float4 fog_params,
    	uniform float4 fog_colour,
    	uniform float4x4 view_matrix,
		uniform float4 tex0BlendColor,
    	uniform float4 multiBlendColor,		
		uniform float4 flowFactor,		
		uniform float4 timeSpeed,		
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);
    
		#if NUM_TEXCOORDS > 0
			
			#if LIGHT_ENABLE
				float4 stageColor = colour;
			#else
				float4 stageColor = float4(1.0,1.0,1.0,colour.w);
			#endif
			stageColor.xyz = stageColor.xyz * (1-tex0BlendColor.w) + tex0BlendColor.xyz * tex0BlendColor.w;
			float4 baseTexColour = tex2D(baseTex, uv.xy);			

     
    		stageColor *= baseTexColour;    	    		      
			oColour = stageColor;

    #else
        oColour.xyz += colour.xyz;
        oColour.w += colour.w;
    #endif
    
    #if LIGHT_ENABLE
    float3 Nn = normalize(normal);
		float3 Ln = normalize(lightDir);
		float3 Vn = normalize(viewDir);
		float3 Hn = normalize(Vn + Ln);
		
    // calculate specular color
		float specularLight = pow(max(dot(Nn, Hn), 0.01), surface_shininess);
		float3 specular = surface_specular_colour.xyz * specularLight * lightSpecular0.xyz;
		oColour.xyz += specular.xyz;
		//oColour.w *= lightOneColour.w;
		#endif
	// ����		
        float4 CtrlTex = tex2D(ctlTex,uv.xy);			
    #if FLOW_LIGHT_TYPE == 0	
		float2 ReflUV = oldNormal.xy;       
		#else
		float2 ReflUV = uv.xy;       
		#endif
		ReflUV = ReflUV.xy * flowFactor.xy + timeSpeed.x * flowFactor.zw * 0.1;
		//ReflUV = ReflUV.xy  + timeSpeed.xy * 0.01;
        //float4 _Reflection_var = tex2D(_Reflection,ReflUV);		        
		//float4 _Reflection_var = tex2D(_Reflection,normal.xy+uvExtern.xy);		        
		float4 _Reflection_var = tex2D(_Reflection,ReflUV);		        
		oColour.xyz += _Reflection_var.xyz*CtrlTex.r;		    
		
		// cal fog
		float4 posInView = mul(view_matrix, float4(posInWorld.xyz, 1.0));
	  oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
		
		oColour.xyz *= multiBlendColor.xyz * multiBlendColor.w;
}


//flowlight fp
void fp_flowlight2_main(
    #if NUM_TEXCOORDS > 0
        in float4 uv       : TEXCOORD0,
        in float4 uvExtern : TEXCOORD1,
        uniform sampler2D baseTex : register(s0),      
      	uniform sampler2D ctlTex : register(s1),    
		uniform sampler2D _Reflection : register(s2),         
    #endif
    
    	in float4 colour		: COLOR0,
    	in float3 normal : TEXCOORD2,
	    in float3 viewDir	: TEXCOORD3,
	    in float3 lightDir : TEXCOORD4,
	    in float3 posInWorld : TEXCOORD7,
	     
	    uniform float4 fog_type,
    	uniform float4 fog_params,
    	uniform float4 fog_colour,
		uniform float4x4 view_matrix,	
		uniform float4 tex0BlendColor,
    	uniform float4 multiBlendColor,		
		uniform float4 flowFactor,		
		uniform float4 timeSpeed,		
	out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);
    
		#if NUM_TEXCOORDS > 0
			
			#if LIGHT_ENABLE
				float4 stageColor = colour;
			#else
				float4 stageColor = float4(1.0,1.0,1.0,colour.w);
			#endif
			//stageColor.xyz = stageColor.xyz * (1-tex0BlendColor.w) + tex0BlendColor.xyz * tex0BlendColor.w;
			//float4 baseTexColour = tex2D(baseTex, uv.xy);
			float4 baseTexColour = tex2D(baseTex, uvExtern.xy);

     
    		stageColor *= baseTexColour;    	    		      
			oColour = stageColor;

    #else
        oColour.xyz += colour.xyz;
        oColour.w += colour.w;
    #endif
    
    
    
    float3 Nn = normalize(normal);
		float3 Ln = normalize(lightDir);
		float3 Vn = normalize(viewDir);
		float3 Hn = normalize(Vn + Ln);
    
	// ����		
        float4 CtrlTex = tex2D(ctlTex,uvExtern.xy);		
		float2 ReflUV = normalize(mul(view_matrix, float4(normal, 0.0))).xy*0.5 + 0.5;       
		//ReflUV = ReflUV.xy * flowFactor.xy + timeSpeed.x * flowFactor.zw;
		//ReflUV = ReflUV.xy  + timeSpeed.xy * 0.01;
        //float4 _Reflection_var = tex2D(_Reflection,ReflUV);		        
		//float4 _Reflection_var = tex2D(_Reflection,normal.xy+uvExtern.xy);		        
		float4 _Reflection_var = tex2D(_Reflection,uv.xy);		        
		oColour.xyz += _Reflection_var.xyz*CtrlTex.r;
		//oColour.xyz += float3(1,0,0)*CtrlTex.r;
    
		// cal fog
		float4 posInView = mul(view_matrix, float4(posInWorld.xyz, 1.0));
	    oColour.xyz = Fogging(oColour.rgb, -posInView.z, fog_type, fog_params, fog_colour);
		
		//oColour.xyz *= multiBlendColor.xyz * multiBlendColor.w;
	
}

