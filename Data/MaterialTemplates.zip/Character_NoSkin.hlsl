/////////////////////////////////////// vp_main //////////////////////////////////


#ifndef NUM_TEXCOORDS
    #define NUM_TEXCOORDS       1
#endif

#if NUM_TEXCOORDS > 0

    #define ORIGINAL_TEXCOORD   0
    #define SINGLE_TEXCOORD     1
    #define PROJECTION_TEXCOORD 2

    #ifndef TEXCOORD_SOURCE
        #define TEXCOORD_SOURCE     ORIGINAL_TEXCOORD
    #endif

#endif

#ifndef LIGHTING_AMBIENT
    #define LIGHTING_AMBIENT    0
#endif

#ifndef USE_VERTEXCOLOR
    #define USE_VERTEXCOLOR          0
#endif

#ifndef NUM_LIGHTS
    #define NUM_LIGHTS          0
#endif

#if NUM_LIGHTS > 0

		//#ifndef ENABLE_SPECULAR
    //    #define ENABLE_SPECULAR     1
    //#endif
    
    #define ARBITRARY_LIGHT     0
    #define DIRECTIONAL_LIGHT   1
    #define POINT_LIGHT         2

    #ifndef LIGHT_TYPE
        #define LIGHT_TYPE          ARBITRARY_LIGHT
    #endif

#endif

#ifndef USE_TANGENT
    #define USE_TANGENT          0
#endif

#ifndef TEX_EFFECT_0
	#define TEX_EFFECT_0 0
#endif

#ifndef TEX_EFFECT_1
	#define TEX_EFFECT_1 0
#endif


void vp_main(
            in float4 position : POSITION,
            
            out float4 oPosition : POSITION,

            #if LIGHTING_AMBIENT || NUM_LIGHTS
                out float4 oColour : COLOR0,

                #if LIGHTING_AMBIENT
                    uniform float4 derived_scene_colour,
                #endif

                #if NUM_LIGHTS
		                in float3 normal : NORMAL,
		                #if USE_TANGENT
		                	in float3 tangent : TANGENT,
		                #endif
		                #if USE_VERTEXCOLOR
		                	in float4 vColor : COLOR0,
		                #endif
		                uniform float4 light_position_array[NUM_LIGHTS],
		
		                #if LIGHT_TYPE != DIRECTIONAL_LIGHT
		                    uniform float4 light_attenuation_array[NUM_LIGHTS],
		                #endif
		                    
		                uniform float4 cameraPos,
		                uniform float4 surface_diffuse_colour,
		                uniform float4 derived_light_diffuse_colour_array[NUM_LIGHTS],
		                
		                uniform float4 actor_ambient_params,
		                uniform float4 actor_lightone_params,
		                uniform float4 actor_lighttwo_params,
		                uniform float4 userflag,
									
										//#if ENABLE_SPECULAR
										out float3 oNormal : TEXCOORD2,
		                out float3 oViewDir : TEXCOORD3, 
		                out float3 oLightDir : TEXCOORD4,
		                out float3 oTangent : TEXCOORD5,
		                out float3 oPosInWorld : TEXCOORD7,
		                out float3 oOldNormal : TEXCOORD6,
		                //#endif
		            #endif         

            #endif

            #if NUM_TEXCOORDS > 0
                    #if TEX_EFFECT_0
                        uniform float4x4 textureTransMatrix0,
                    #endif
                    #if TEX_EFFECT_1
                    		uniform float4x4 textureTransMatrix1,
                    #endif
                				in float4 uv0 : TEXCOORD0,
                        out float4 oTexcoords : TEXCOORD0,
                        out float4 oUVExtern : TEXCOORD1,
            #endif
			uniform float4x4 world_matrix,
            uniform float4x4 viewproj_matrix )
{
    float4 worldPos = mul(world_matrix, position);
    oPosition = mul(viewproj_matrix, worldPos);

#if NUM_TEXCOORDS > 0
    // Calculate texcoords
    #if TEX_EFFECT_0
    	oTexcoords = mul( textureTransMatrix0, uv0 );
    #else
    	oTexcoords = uv0;
    #endif
    #if TEX_EFFECT_1
    	oUVExtern = mul( textureTransMatrix1, uv0 );
    #else
    	oUVExtern = uv0;
		#endif
#endif

#if LIGHTING_AMBIENT
    oColour = derived_scene_colour;
#endif

#if NUM_LIGHTS
		oPosInWorld = worldPos.xyz;
		
		float3 worldNorm = float3(0,0,0);
    float3 worldTanget = float3(0,0,0);
    oOldNormal = normal;
		worldNorm = mul(world_matrix, float4(normal, 0.0)).xyz;
    worldNorm = normalize(worldNorm);
    #if USE_TANGENT
        worldTanget = mul( world_matrix, float4(tangent, 0.0) );
        worldTanget = normalize(worldTanget);
    #endif
    
    oColour = derived_scene_colour * (1.0 - userflag.x) + actor_ambient_params * userflag.x;

		float4 lightDiffuseColor[NUM_LIGHTS];
		lightDiffuseColor[0] = derived_light_diffuse_colour_array[0] * (1.0 - userflag.x) + actor_lightone_params * surface_diffuse_colour * userflag.x;
		lightDiffuseColor[1] = derived_light_diffuse_colour_array[1] * (1.0 - userflag.x) + actor_lighttwo_params * surface_diffuse_colour * userflag.x;
		lightDiffuseColor[2] = derived_light_diffuse_colour_array[2];
		
		#if USE_VERTEXCOLOR
    	oColour.a *= vColor.a;
    	lightDiffuseColor[0].rgb *= vColor.rgb;
			lightDiffuseColor[1].rgb *= vColor.rgb;
			lightDiffuseColor[2].rgb *= vColor.rgb;
    #endif
    
    #if !LIGHTING_AMBIENT
        oColour = float4(0, 0, 0, lightDiffuseColor[0].a);
    #endif

        for (int l = 0; l < NUM_LIGHTS; ++l)
        {
    #if LIGHT_TYPE == DIRECTIONAL_LIGHT
            // Lighting - support directional light only
            float3 lightDir = light_position_array[l].xyz;
    #elif LIGHT_TYPE == POINT_LIGHT
            // Lighting - support point light only
            float3 lightDir = light_position_array[l].xyz - worldPos;
    #else
            // Lighting - support point and directional light
            float3 lightDir = light_position_array[l].xyz - (worldPos.xyz * light_position_array[l].w);
    #endif
            float d = length(lightDir);
            lightDir /= d;

            float ndotl = dot(worldNorm, lightDir);
    //#if ENABLE_SPECULAR
						if (l == 0)
		        {
		            oNormal = worldNorm;
		            oLightDir = lightDir;
		     				oViewDir = cameraPos.xyz - worldPos.xyz;
		     				oTangent = worldTanget;
		        }
		//#endif
            float3 colour = max(ndotl, 0) * lightDiffuseColor[l].rgb;
    
    #if LIGHT_TYPE == DIRECTIONAL_LIGHT
            float att = 1;
    #elif LIGHT_TYPE == POINT_LIGHT
            float att = 1 / (light_attenuation_array[l].y + d * (light_attenuation_array[l].z + d * light_attenuation_array[l].w));
    #else
            float att = lerp(0, 1, 1 / dot(float3(1, d, d*d), light_attenuation_array[l].yzw));
    #endif

            oColour.rgb += att * colour;
        }
        oColour.rgb = saturate(oColour.rgb);
#endif

}



