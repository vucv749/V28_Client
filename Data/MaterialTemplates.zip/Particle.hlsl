/////////////////////////////////////// vp_main //////////////////////////////////
#ifndef MAX_WORLD_MATRICES
    #define MAX_WORLD_MATRICES 25
#endif

#ifndef MAX_BLEND_WEIGHTS
    #define MAX_BLEND_WEIGHTS	1
#endif

#ifndef USE_LAST_WEIGHT
    #if MAX_BLEND_WEIGHTS != 3
        #define USE_LAST_WEIGHT     1
    #else
        #define USE_LAST_WEIGHT     0
    #endif
#endif

#ifndef TEX_EFFECT_0
	#define TEX_EFFECT_0 0
#endif

#ifndef TEX_EFFECT_1
	#define TEX_EFFECT_1 0
#endif

#ifndef ENABLE_DIFFUSE_2
	#define ENABLE_DIFFUSE_2 0
#endif

#define BLEND_OP_MODULATE   0
#define BLEND_OP_MODULATE2     1
#define BLEND_OP_MODULATE4     2
#define BLEND_OP_ADD     3
#define BLEND_OP_CUSTOM     4

// process the ColorOp of texUnit0
#if NUM_TEXCOORDS > 0
	#ifndef BLEND_OP_0
			#define BLEND_OP_0 BLEND_OP_MODULATE
	#endif
#endif

// process the ColorOp of texUnit1
#if ENABLE_DIFFUSE_2 > 0
	#ifndef BLEND_OP_1
			#define BLEND_OP_1 BLEND_OP_MODULATE
	#endif
#endif

#ifndef LIGHT_ENABLE
    #define LIGHT_ENABLE          1
#endif

void vp_main(
            in float4 position : POSITION,
            in float4 color : COLOR0,
            in float4 uv0 : TEXCOORD0,

            #if MAX_BLEND_WEIGHTS > 0
            	in int4 blendIndex : BLENDINDICES,
              in float4 blendWeight : BLENDWEIGHT,
            #endif

            out float4 oPosition : POSITION,
            out float4 oColour : COLOR0,
            out float4 oUV0 : TEXCOORD0,
            out float4 oUV1 : TEXCOORD1,
            
            uniform float4 surface_emissive_colour,
            
            //#if TEX_EFFECT_0
              uniform float4x4 textureTransMatrix0,
            //#endif
            //#if TEX_EFFECT_1
              uniform float4x4 textureTransMatrix1,
            //#endif
            
            #if MAX_BLEND_WEIGHTS > 0
            	uniform float3x4 worldMatrix3x4Array[MAX_WORLD_MATRICES],
            #else
            	uniform float4x4 world_matrix,
            #endif
            uniform float4x4 view_matrix,
            uniform float4x4 projection_matrix
)
{
    // transform to world space by indexed matrices
    float4 worldPos = float4(0,0,0,0);
    
#if MAX_BLEND_WEIGHTS > 0
	float3 blendPos = float3(0,0,0);
	#if USE_LAST_WEIGHT
    // Use this to avoid weight by last component of blendWeights, which
    // maybe wrong when number of weights equal four.
    float lastWeight = 1;

    #if MAX_BLEND_WEIGHTS > 1
        for (int i = 0; i < MAX_BLEND_WEIGHTS-1; ++i)
        {
            lastWeight -= blendWeight[i];
            blendPos += mul(worldMatrix3x4Array[blendIndex[i]], position) * blendWeight[i];
            
            #if NUM_LIGHTS
                blendNorm += mul( (float3x3)worldMatrix3x4Array[blendIndex[i]], normal ) * blendWeight[i];
            #endif
        }
    #endif
		lastWeight = step(0.001, lastWeight) * lastWeight;
    blendPos += mul(worldMatrix3x4Array[blendIndex[MAX_BLEND_WEIGHTS-1]], position) * lastWeight;

	#else // !USE_LAST_WEIGHT

    for (int i = 0; i < MAX_BLEND_WEIGHTS; ++i)
    {
        blendPos += mul(worldMatrix3x4Array[blendIndex[i]], position)
        #if MAX_BLEND_WEIGHTS > 1
            * blendWeight[i]
        #endif
            ;
    }
   #endif
   
   worldPos = float4(blendPos.xyz, 1.0);
#else
		worldPos = mul(world_matrix, position);
#endif
		float4 posInView = mul( view_matrix, worldPos );
    oPosition = mul( projection_matrix, posInView ); 
		oColour = saturate(color + surface_emissive_colour);
		oColour.a = color.a;
		// Calculate texcoords
    //#if TEX_EFFECT_0
    	oUV0 = mul( textureTransMatrix0, uv0 );
    //#else
    //	oUV0 = uv0;
    //#endif
    //#if TEX_EFFECT_1
    	oUV1 = mul( textureTransMatrix1, uv0 );
    //#else
   // 	oUV1 = uv0;
		//#endif



}

/////////////////////////////////////// fp_main //////////////////////////////////

void fp_main(
    		in float4 uv0 : TEXCOORD0,
        in float4 uv1 : TEXCOORD1,
        in float4 colour : COLOR0,
        uniform sampler2D baseTex : register(s0),
      #if ENABLE_DIFFUSE_2
      		uniform sampler2D diffuse2Tex : register(s1),
      #endif
      
				out float4 oColour	: COLOR )
{
    oColour = float4(0.0,0.0,0.0,1.0);
    
    #if LIGHT_ENABLE
			float4 stageColor = colour;
		#else
			float4 stageColor = float4(1.0,1.0,1.0,colour.w);
		#endif

    float4 baseTexColour = tex2D(baseTex, uv0.xy);
    #if BLEND_OP_0 == 1
      	stageColor.xyz *= baseTexColour.xyz * 2.0;
    #elif BLEND_OP_0 == 2
      	stageColor.xyz *= baseTexColour.xyz * 4.0;
    #elif BLEND_OP_0 == 3
      	stageColor.xyz += baseTexColour.xyz;
    #else
    		stageColor.xyz *= baseTexColour.xyz;
    #endif
    	stageColor.w *= baseTexColour.w;
      
    #if ENABLE_DIFFUSE_2
				float4 diffuse2TexColour = tex2D(diffuse2Tex, uv1.xy);
    	#if BLEND_OP_1 == 1
      		stageColor.xyz *= diffuse2TexColour.xyz * 2.0;
    	#elif BLEND_OP_1 == 2
      		stageColor.xyz *= diffuse2TexColour.xyz * 4.0;
    	#elif BLEND_OP_1 == 3
      		stageColor.xyz += diffuse2TexColour.xyz;
    	#else
      		stageColor.xyz *= diffuse2TexColour.xyz;
    	#endif
      	stageColor.w *= diffuse2TexColour.w;
		#endif

			oColour = stageColor;

}

