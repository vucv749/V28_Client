//////////////////////////////////////////////
//				 CASTER PASS				//
//				    HEAT					//
//////////////////////////////////////////////

// vs_1_1
void
HeatCaster_vp(
              // in
              in float4 vPos: POSITION,
              in float3 vNormal: NORMAL,

              // out
              out float4 oPos: POSITION,
              out float2 oNDotV: TEXCOORD0,

              // parameters
              uniform float4x4 worldViewProj,
              uniform float3 eyePosition        // object space
             )
{
   float3 eyeDir = eyePosition - vPos.xyz;
   eyeDir = normalize(eyeDir);
   oPos   = mul(worldViewProj, vPos);
   oNDotV = clamp(dot(vNormal, eyeDir), 0, 1);
}

// ps_2_0
float4
HeatCaster_fp(
              // input from vp
              in float2 iNDotV: TEXCOORD0
             ) : COLOR
{
   return iNDotV.x;
}


//////////////////////////////////////////////
//				 CASTER PASS				//
//				    COLD					//
//////////////////////////////////////////////

// vs_1_1
void
ColdCaster_vp(
              // in
              in float4 vPos: POSITION,
              in float3 vNormal: NORMAL,

              // out
              out float4 oPos: POSITION,
              out float2 oNDotV: TEXCOORD0,

              // parameters
              uniform float4x4 worldViewProj,
              uniform float3 eyePosition        // object space
             )
{
   float3 eyeDir = eyePosition - vPos.xyz;
   eyeDir = normalize(eyeDir);
   oPos   = mul(worldViewProj, vPos);
   oNDotV = clamp(dot(vNormal, eyeDir), 0, 1);
}

// ps_2_0
float4
ColdCaster_fp(
              // input from vp
              float2 iNDotV: TEXCOORD0
             ) : COLOR
{
   return iNDotV.x / 2;
}


//////////////////////////////////////////////
//	   PASS 1 - Light to heat conversion	//
//////////////////////////////////////////////

// ps_2_0
float4
LightToHeat_fp(float4 pos : POSITION,
               // input from vp
               in float2 inUV0: TEXCOORD0,

               // parameters
               uniform float4 random_fractions,
               uniform float4 heatBiasScale,
               uniform float4 depth_modulator,

               uniform sampler2D Input,         // output of HeatVisionCaster_fp (NdotV)
               uniform sampler2D NoiseMap,
               uniform sampler2D HeatLookup
              ) : COLOR
{
   float  depth, heat, interference;

   //  Output constant color:
   depth = tex2D(Input, inUV0);
   depth *= (depth * depth_modulator);

   heat  = (depth * heatBiasScale.y);

//   if (depth > 0)
   {
		interference = -0.5 + tex2D(NoiseMap, inUV0 + float2(random_fractions.x, random_fractions.y));
		interference *= interference;
		interference *= 1 - heat;
		heat += interference;//+ heatBiasScale.x;
   }

/*
	heatBias isn't used for now
   if (heat > 0)
       heat += heatBiasScale.x;
*/

   // Clamp UVs
   heat  = max(0.005, min(0.995, heat));

   return tex2D(HeatLookup, float2(heat, 0.f));
}


//////////////////////////////////////////////
// PASS 2 - add simple blur (final pass)	//
//////////////////////////////////////////////

// ps_2_0
float4
Blur_fp(float4 pos : POSITION,
        // input from vp
        in float2 inUV0: TEXCOORD0,

        // parameters
        uniform sampler2D Input,             // output of HeatVision_fp1 (HeatRenderTexture)
        uniform float4 blurAmount
       ) : COLOR
{
   static const float2 offsets[4] =
   {
	  {-0.3, -0.4},
	  {-0.3, +0.4},
	  {+0.3, -0.4},
	  {+0.3, +0.4},
   };

   float4 tmpOutColor = tex2D(Input, inUV0);	// UV coords are in image space

   // calculate glow amount
   float diffuseGlowFactor = 0.0113f * (2.0 - max(tmpOutColor.r, tmpOutColor.g));

   // basic blur filter
   for (int i = 0; i < 4; i++)
   {
      tmpOutColor += tex2D(Input, inUV0 + blurAmount.x * diffuseGlowFactor * offsets[i]);
   }

   return tmpOutColor / 4;
}
