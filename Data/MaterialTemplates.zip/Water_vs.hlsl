#ifndef _Water_VS_H_
#define _Water_VS_H_

// Define In VS
#define __VS__



#include "WaterDef.inc"

VS_OUT main( VS_IN IN )
{
	VS_OUT OUT = (VS_OUT)0;
	
	OUT.oPos = mul(worldviewproj_matrix, IN.position);
	OUT.oPosInView = mul(worldview_matrix, IN.position);
	float4x4 scalemat = float4x4(0.5,   0,   0, 0.5, 
	                              0,-0.5,   0, 0.5,
								   							0,   0, 0.5, 0.5,
								   							0,   0,   0,   1);
	OUT.oUVScreen = mul(scalemat, OUT.oPos);
	OUT.oEyeDir = camera_position_object_space - IN.position.xyz;
	OUT.oCamFrontDir = mul(world_matrix, view_direction);
	
	OUT.oUV = IN.uv0.xyxy;
	
	return OUT;
}

#endif


